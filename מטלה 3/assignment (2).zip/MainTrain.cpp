#include "str.h"

int main()
{
	cout << "done" << endl;
	return 0;
}